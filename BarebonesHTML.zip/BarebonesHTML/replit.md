# Overview

This is a simple static website built with pure HTML and CSS, demonstrating clean, minimal web development without JavaScript or external dependencies. The site consists of three pages (Home, About, Contact) with a focus on fast loading, accessibility, and maintainability. It showcases a philosophy of simplicity in web development.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Static Site Structure**: Traditional multi-page website using separate HTML files for each page (index.html, about.html, contact.html)
- **CSS-Only Styling**: Single stylesheet (styles.css) handles all visual presentation across the site
- **No JavaScript**: Deliberately excludes client-side scripting for maximum simplicity and performance
- **Responsive Design**: Uses CSS flexbox and modern layout techniques for mobile-friendly design

## Navigation System
- **Simple Navigation**: Horizontal navigation bar with active state management through CSS classes
- **Cross-Page Linking**: Standard HTML anchor links between pages
- **Active State Indication**: Visual feedback for current page using CSS styling

## Design Philosophy
- **Minimal Dependencies**: Zero external libraries, frameworks, or CDN resources
- **Performance First**: Optimized for fast loading with minimal HTTP requests
- **Accessibility Focus**: Semantic HTML structure with proper heading hierarchy
- **Clean Typography**: System font stack for consistent cross-platform appearance

## Content Structure
- **Semantic HTML**: Proper use of header, nav, main, section, and footer elements
- **Consistent Layout**: Shared header/navigation across all pages with page-specific content areas
- **Contact Information**: Static contact details presented in structured format

# External Dependencies

## Core Technologies
- **HTML5**: Semantic markup and document structure
- **CSS3**: Styling, layout, and responsive design features
- **System Fonts**: Relies on operating system font stack (no web fonts)

## No External Dependencies
- No JavaScript libraries or frameworks
- No CSS frameworks (Bootstrap, etc.)
- No CDN resources
- No third-party APIs or services
- No build tools or preprocessors
- No external hosting dependencies beyond basic web server