# Weather Alert Agent

## Overview

This is a full-stack weather alert application built with React/TypeScript frontend and Express/Node.js backend. The application provides users with personalized weather notifications based on their location and preferences. Users can set up alerts for specific weather conditions (rain, snow, storms, extreme weather) and receive notifications via both email and SMS at their preferred frequency.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with shadcn/ui component library
- **UI Components**: Radix UI primitives for accessibility
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Validation**: Zod for runtime type checking
- **Email Service**: Nodemailer for sending weather alerts via SMTP
- **SMS Service**: Twilio for sending weather alerts via SMS
- **Task Scheduling**: node-cron for automated weather monitoring
- **Weather Data**: WeatherAPI integration for real-time weather information

## Key Components

### Core Services
1. **Weather Service**: Fetches current weather, forecasts, and alerts from WeatherAPI
2. **Email Service**: Handles sending weather alerts and test emails via SMTP
3. **SMS Service**: Handles sending weather alerts and test SMS via Twilio
4. **Scheduler Service**: Runs automated weather checks every 15 minutes for both email and SMS
5. **Storage Service**: Manages user data, weather settings, and activity logs

### Database Schema
- **Users**: Stores user email, location, coordinates, and active status
- **Weather Settings**: User preferences for notification frequency, weather conditions, notification methods (email/SMS), and phone number
- **Activity Logs**: Tracks user actions and system events
- **Weather Data**: Caches weather information for users

### Frontend Components
- **Dashboard**: Main interface showing weather status and user controls
- **Status Cards**: Display current location, weather alerts, and notification count
- **Weather Card**: Shows current weather conditions with icons
- **Forecast Card**: 5-day weather forecast display
- **Settings Card**: User preferences configuration
- **Activity Card**: Recent activity and notification history

## Data Flow

1. **User Registration**: Users provide email and location preferences
2. **Location Detection**: Browser geolocation API or manual location input
3. **Weather Monitoring**: Scheduled service checks weather conditions every 15 minutes
4. **Alert Processing**: System evaluates weather conditions against user preferences
5. **Notifications**: Automated emails and SMS sent based on user frequency and method preferences
6. **Activity Logging**: All actions and notifications are tracked for user visibility

## External Dependencies

### Core Dependencies
- **Database**: Neon PostgreSQL for cloud database hosting
- **Weather API**: WeatherAPI for weather data and alerts
- **Email Service**: SMTP-based email delivery (Gmail or custom)
- **SMS Service**: Twilio for SMS delivery and notifications
- **UI Libraries**: Radix UI for accessible components
- **Validation**: Zod for schema validation

### Development Tools
- **TypeScript**: Static type checking
- **Vite**: Fast build tool and development server
- **Tailwind CSS**: Utility-first CSS framework
- **ESLint/Prettier**: Code formatting and linting

## Deployment Strategy

### Development
- **Local Development**: Vite dev server for frontend, tsx for backend
- **Environment Variables**: DATABASE_URL, WEATHER_API_KEY, SMTP credentials, Twilio credentials
- **Hot Reload**: Vite HMR for frontend, tsx watch mode for backend

### Production
- **Build Process**: Vite builds frontend, esbuild bundles backend
- **Static Assets**: Frontend built to dist/public directory
- **Server Bundle**: Backend compiled to dist/index.js
- **Database**: Drizzle migrations handle schema changes
- **Environment**: Production environment variables required (WEATHER_API_KEY, SMTP_USER, SMTP_PASS, TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER)

### Key Features
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Real-time Updates**: Weather data refreshes every minute on dashboard
- **User Experience**: Toast notifications for user feedback
- **Accessibility**: ARIA-compliant components via Radix UI
- **Type Safety**: Full TypeScript coverage across frontend and backend
- **Multi-Channel Notifications**: Support for both email and SMS notifications
- **Test Functionality**: Built-in test email and SMS sending capabilities
- **Configurable Methods**: Users can enable/disable email and SMS independently