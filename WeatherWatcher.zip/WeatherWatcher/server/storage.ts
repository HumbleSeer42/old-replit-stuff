import { 
  users, 
  weatherSettings, 
  activityLogs, 
  weatherData,
  type User, 
  type InsertUser,
  type WeatherSettings,
  type InsertWeatherSettings,
  type ActivityLog,
  type InsertActivityLog,
  type WeatherData,
  type InsertWeatherData
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  // Weather settings operations
  getWeatherSettings(userId: number): Promise<WeatherSettings | undefined>;
  createWeatherSettings(settings: InsertWeatherSettings): Promise<WeatherSettings>;
  updateWeatherSettings(userId: number, settings: Partial<InsertWeatherSettings>): Promise<WeatherSettings | undefined>;
  
  // Activity log operations
  getActivityLogs(userId: number, limit?: number): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  
  // Weather data operations
  getWeatherData(userId: number): Promise<WeatherData | undefined>;
  createWeatherData(data: InsertWeatherData): Promise<WeatherData>;
  updateWeatherData(userId: number, data: Partial<InsertWeatherData>): Promise<WeatherData | undefined>;
  
  // Stats
  getNotificationCount(userId: number): Promise<number>;
  getAllActiveUsers(): Promise<User[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private weatherSettings: Map<number, WeatherSettings>;
  private activityLogs: Map<number, ActivityLog[]>;
  private weatherData: Map<number, WeatherData>;
  private currentUserId: number;
  private currentSettingsId: number;
  private currentLogId: number;
  private currentWeatherDataId: number;

  constructor() {
    this.users = new Map();
    this.weatherSettings = new Map();
    this.activityLogs = new Map();
    this.weatherData = new Map();
    this.currentUserId = 1;
    this.currentSettingsId = 1;
    this.currentLogId = 1;
    this.currentWeatherDataId = 1;

    // Create a default test user for development
    this.initializeTestUser();
  }

  private initializeTestUser(): void {
    const testUser: User = {
      id: 1,
      email: "test@example.com",
      location: "New York, NY",
      latitude: "40.7128",
      longitude: "-74.0060",
      isActive: true,
      createdAt: new Date(),
    };
    
    const testSettings: WeatherSettings = {
      id: 1,
      userId: 1,
      frequency: "immediate",
      conditions: { rain: true, snow: true, storms: true, extreme: false },
      notificationMethods: { email: true, sms: false },
      phoneNumber: null,
      createdAt: new Date(),
    };

    this.users.set(1, testUser);
    this.weatherSettings.set(1, testSettings);
    this.currentUserId = 2;
    this.currentSettingsId = 2;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      isActive: true,
      location: insertUser.location || null,
      latitude: insertUser.latitude || null,
      longitude: insertUser.longitude || null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getWeatherSettings(userId: number): Promise<WeatherSettings | undefined> {
    return Array.from(this.weatherSettings.values()).find(settings => settings.userId === userId);
  }

  async createWeatherSettings(insertSettings: InsertWeatherSettings): Promise<WeatherSettings> {
    const id = this.currentSettingsId++;
    const settings: WeatherSettings = {
      ...insertSettings,
      id,
      createdAt: new Date(),
      userId: insertSettings.userId || null,
      frequency: insertSettings.frequency || 'immediate',
      conditions: insertSettings.conditions || { rain: true, snow: true, storms: true, extreme: false },
      notificationMethods: insertSettings.notificationMethods || { email: true, sms: false },
      phoneNumber: insertSettings.phoneNumber || null
    };
    this.weatherSettings.set(id, settings);
    return settings;
  }

  async updateWeatherSettings(userId: number, settingsData: Partial<InsertWeatherSettings>): Promise<WeatherSettings | undefined> {
    const settings = Array.from(this.weatherSettings.values()).find(s => s.userId === userId);
    if (!settings) return undefined;
    
    const updatedSettings = { ...settings, ...settingsData };
    this.weatherSettings.set(settings.id, updatedSettings);
    return updatedSettings;
  }

  async getActivityLogs(userId: number, limit: number = 10): Promise<ActivityLog[]> {
    const logs = this.activityLogs.get(userId) || [];
    return logs.slice(-limit).reverse();
  }

  async createActivityLog(insertLog: InsertActivityLog): Promise<ActivityLog> {
    const id = this.currentLogId++;
    const log: ActivityLog = {
      ...insertLog,
      id,
      createdAt: new Date(),
      userId: insertLog.userId || null,
      data: insertLog.data || null
    };
    
    const userLogs = this.activityLogs.get(insertLog.userId!) || [];
    userLogs.push(log);
    this.activityLogs.set(insertLog.userId!, userLogs);
    
    return log;
  }

  async getWeatherData(userId: number): Promise<WeatherData | undefined> {
    return Array.from(this.weatherData.values()).find(data => data.userId === userId);
  }

  async createWeatherData(insertData: InsertWeatherData): Promise<WeatherData> {
    const id = this.currentWeatherDataId++;
    const data: WeatherData = {
      ...insertData,
      id,
      updatedAt: new Date(),
      userId: insertData.userId || null,
      currentTemp: insertData.currentTemp || null,
      currentCondition: insertData.currentCondition || null,
      forecastData: insertData.forecastData || null,
      alertData: insertData.alertData || null
    };
    this.weatherData.set(id, data);
    return data;
  }

  async updateWeatherData(userId: number, weatherDataUpdate: Partial<InsertWeatherData>): Promise<WeatherData | undefined> {
    const data = Array.from(this.weatherData.values()).find(d => d.userId === userId);
    if (!data) return undefined;
    
    const updatedData = { ...data, ...weatherDataUpdate, updatedAt: new Date() };
    this.weatherData.set(data.id, updatedData);
    return updatedData;
  }

  async getNotificationCount(userId: number): Promise<number> {
    const logs = this.activityLogs.get(userId) || [];
    return logs.filter(log => log.type === 'email_sent' || log.type === 'sms_sent').length;
  }

  async getAllActiveUsers(): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.isActive);
  }
}

export const storage = new MemStorage();
