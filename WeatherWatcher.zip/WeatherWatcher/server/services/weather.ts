import axios from 'axios';

interface WeatherResponse {
  current: {
    temp_f: number;
    temp_c: number;
    condition: {
      text: string;
    };
  };
  forecast: {
    forecastday: Array<{
      date: string;
      day: {
        maxtemp_f: number;
        maxtemp_c: number;
        mintemp_f: number;
        mintemp_c: number;
        condition: {
          text: string;
        };
      };
    }>;
  };
  alerts?: {
    alert: Array<{
      headline: string;
      desc: string;
      severity: string;
    }>;
  };
}

interface LocationResponse {
  name: string;
  region: string;
  country: string;
  lat: number;
  lon: number;
}

export class WeatherService {
  private apiKey: string;
  private baseUrl: string;

  constructor() {
    this.apiKey = process.env.WEATHER_API_KEY || process.env.WEATHERAPI_KEY || '';
    this.baseUrl = 'https://api.weatherapi.com/v1';
  }

  async getCurrentWeather(location: string): Promise<WeatherResponse> {
    try {
      const response = await axios.get(`${this.baseUrl}/forecast.json`, {
        params: {
          key: this.apiKey,
          q: location,
          days: 5,
          aqi: 'no',
          alerts: 'yes'
        }
      });
      
      return response.data;
    } catch (error) {
      console.error('Weather API Error:', error);
      throw new Error('Failed to fetch weather data');
    }
  }

  async searchLocation(query: string): Promise<LocationResponse[]> {
    try {
      const response = await axios.get(`${this.baseUrl}/search.json`, {
        params: {
          key: this.apiKey,
          q: query
        }
      });
      
      return response.data;
    } catch (error) {
      console.error('Location search error:', error);
      throw new Error('Failed to search location');
    }
  }

  async getLocationByCoordinates(lat: number, lon: number): Promise<LocationResponse> {
    try {
      const response = await axios.get(`${this.baseUrl}/search.json`, {
        params: {
          key: this.apiKey,
          q: `${lat},${lon}`
        }
      });
      
      return response.data[0];
    } catch (error) {
      console.error('Reverse geocoding error:', error);
      throw new Error('Failed to get location from coordinates');
    }
  }

  shouldSendAlert(weatherData: WeatherResponse, conditions: any): boolean {
    const currentCondition = weatherData.current.condition.text.toLowerCase();
    const alerts = weatherData.alerts?.alert || [];
    
    // Check for active weather alerts
    if (alerts.length > 0) {
      return true;
    }
    
    // Check for specific weather conditions
    if (conditions.rain && (currentCondition.includes('rain') || currentCondition.includes('drizzle'))) {
      return true;
    }
    
    if (conditions.snow && (currentCondition.includes('snow') || currentCondition.includes('blizzard'))) {
      return true;
    }
    
    if (conditions.storms && (currentCondition.includes('thunder') || currentCondition.includes('storm'))) {
      return true;
    }
    
    if (conditions.extreme && (currentCondition.includes('tornado') || currentCondition.includes('hurricane'))) {
      return true;
    }
    
    return false;
  }

  formatWeatherForEmail(weatherData: WeatherResponse, location: string): string {
    const current = weatherData.current;
    const forecast = weatherData.forecast.forecastday;
    const alerts = weatherData.alerts?.alert || [];
    
    let emailContent = `Weather Alert for ${location}\n\n`;
    
    emailContent += `Current Conditions:\n`;
    emailContent += `Temperature: ${current.temp_f}°F\n`;
    emailContent += `Condition: ${current.condition.text}\n\n`;
    
    if (alerts.length > 0) {
      emailContent += `Weather Alerts:\n`;
      alerts.forEach(alert => {
        emailContent += `- ${alert.headline}\n`;
        emailContent += `  ${alert.desc}\n\n`;
      });
    }
    
    emailContent += `5-Day Forecast:\n`;
    forecast.forEach(day => {
      emailContent += `${day.date}: ${day.day.condition.text}, High: ${day.day.maxtemp_f}°F, Low: ${day.day.mintemp_f}°F\n`;
    });
    
    return emailContent;
  }
}

export const weatherService = new WeatherService();
