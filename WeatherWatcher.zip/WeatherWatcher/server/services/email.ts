import nodemailer from 'nodemailer';

export class EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.SMTP_USER || process.env.EMAIL_USER,
        pass: process.env.SMTP_PASS || process.env.EMAIL_PASS
      }
    });
  }

  async sendWeatherAlert(to: string, subject: string, content: string): Promise<void> {
    try {
      const mailOptions = {
        from: process.env.SMTP_USER || process.env.EMAIL_USER,
        to,
        subject,
        text: content,
        html: this.formatHtmlEmail(content)
      };

      await this.transporter.sendMail(mailOptions);
    } catch (error) {
      console.error('Email sending error:', error);
      throw new Error('Failed to send email');
    }
  }

  async sendTestEmail(to: string): Promise<void> {
    const subject = 'Weather Alert Agent - Test Email';
    const content = `This is a test email from your Weather Alert Agent.

The service is working correctly and will send you notifications when weather conditions match your preferences.

Current settings:
- Email: ${to}
- Status: Active

If you received this email, your notification system is working properly.`;

    await this.sendWeatherAlert(to, subject, content);
  }

  private formatHtmlEmail(textContent: string): string {
    return `
      <html>
        <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: #f8fafc; padding: 20px; border-radius: 8px;">
            <h2 style="color: #2563eb; margin-bottom: 20px;">
              🌦️ Weather Alert Agent
            </h2>
            <div style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #2563eb;">
              <pre style="font-family: Arial, sans-serif; white-space: pre-wrap; margin: 0;">${textContent}</pre>
            </div>
            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #e2e8f0; color: #64748b; font-size: 12px;">
              <p>This is an automated message from Weather Alert Agent. To modify your settings, please visit your dashboard.</p>
            </div>
          </div>
        </body>
      </html>
    `;
  }
}

export const emailService = new EmailService();
