import cron from 'node-cron';
import { storage } from '../storage';
import { weatherService } from './weather';
import { emailService } from './email';
import { smsService } from './sms';

export class SchedulerService {
  private jobs: Map<string, cron.ScheduledTask> = new Map();

  startWeatherMonitoring(): void {
    // Check weather every 15 minutes
    const task = cron.schedule('*/15 * * * *', async () => {
      await this.checkWeatherForAllUsers();
    });

    this.jobs.set('weather-monitor', task);
    console.log('Weather monitoring scheduler started');
  }

  private async checkWeatherForAllUsers(): Promise<void> {
    try {
      const users = await storage.getAllActiveUsers();
      
      for (const user of users) {
        if (!user.location || !user.email) continue;
        
        const settings = await storage.getWeatherSettings(user.id);
        if (!settings) continue;
        
        // Skip if frequency is daily and we've already sent today
        if (settings.frequency === 'daily') {
          const logs = await storage.getActivityLogs(user.id, 50);
          const today = new Date().toDateString();
          const sentToday = logs.some(log => 
            (log.type === 'email_sent' || log.type === 'sms_sent') && 
            log.createdAt?.toDateString() === today
          );
          if (sentToday) continue;
        }
        
        // Skip if frequency is hourly and we've sent in the last hour
        if (settings.frequency === 'hourly') {
          const logs = await storage.getActivityLogs(user.id, 10);
          const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
          const sentRecently = logs.some(log => 
            (log.type === 'email_sent' || log.type === 'sms_sent') && 
            log.createdAt && log.createdAt > oneHourAgo
          );
          if (sentRecently) continue;
        }
        
        await this.checkWeatherForUser(user.id);
      }
    } catch (error) {
      console.error('Weather monitoring error:', error);
    }
  }

  private async checkWeatherForUser(userId: number): Promise<void> {
    try {
      const user = await storage.getUser(userId);
      const settings = await storage.getWeatherSettings(userId);
      
      if (!user || !settings || !user.location) return;
      
      const weatherData = await weatherService.getCurrentWeather(user.location);
      
      // Update weather data in storage
      await storage.updateWeatherData(userId, {
        userId,
        location: user.location,
        currentTemp: `${weatherData.current.temp_f}°F`,
        currentCondition: weatherData.current.condition.text,
        forecastData: weatherData.forecast,
        alertData: weatherData.alerts
      });
      
      // Log weather update
      await storage.createActivityLog({
        userId,
        type: 'weather_updated',
        message: 'Weather data updated successfully',
        data: { location: user.location, temp: weatherData.current.temp_f }
      });
      
      // Check if alert should be sent
      if (weatherService.shouldSendAlert(weatherData, settings.conditions)) {
        const notificationMethods = settings.notificationMethods || { email: true, sms: false };
        
        // Send email notification if enabled
        if (notificationMethods.email && user.email) {
          const emailContent = weatherService.formatWeatherForEmail(weatherData, user.location);
          const subject = `Weather Alert for ${user.location}`;
          
          try {
            await emailService.sendWeatherAlert(user.email, subject, emailContent);
            
            // Log email sent
            await storage.createActivityLog({
              userId,
              type: 'email_sent',
              message: `Weather alert email sent for ${weatherData.current.condition.text}`,
              data: { 
                condition: weatherData.current.condition.text,
                temp: weatherData.current.temp_f,
                location: user.location
              }
            });
          } catch (error) {
            console.error(`Failed to send email to user ${userId}:`, error);
          }
        }
        
        // Send SMS notification if enabled and configured
        if (notificationMethods.sms && settings.phoneNumber && smsService.isConfigured()) {
          const smsContent = smsService.formatWeatherSMS(
            { currentTemp: `${weatherData.current.temp_f}°F`, currentCondition: weatherData.current.condition.text, alertData: weatherData.alerts },
            user.location,
            weatherData.current.condition.text
          );
          
          try {
            await smsService.sendWeatherAlert(settings.phoneNumber, smsContent);
            
            // Log SMS sent
            await storage.createActivityLog({
              userId,
              type: 'sms_sent',
              message: `Weather alert SMS sent for ${weatherData.current.condition.text}`,
              data: { 
                condition: weatherData.current.condition.text,
                temp: weatherData.current.temp_f,
                location: user.location,
                phoneNumber: settings.phoneNumber
              }
            });
          } catch (error) {
            console.error(`Failed to send SMS to user ${userId}:`, error);
          }
        }
      }
    } catch (error) {
      console.error(`Error checking weather for user ${userId}:`, error);
      
      // Log error
      await storage.createActivityLog({
        userId,
        type: 'error',
        message: 'Failed to check weather data',
        data: { error: error.message }
      });
    }
  }

  stopWeatherMonitoring(): void {
    const task = this.jobs.get('weather-monitor');
    if (task) {
      task.stop();
      this.jobs.delete('weather-monitor');
      console.log('Weather monitoring scheduler stopped');
    }
  }
}

export const schedulerService = new SchedulerService();
