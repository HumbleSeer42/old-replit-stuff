import twilio from 'twilio';

export class SMSService {
  private client: twilio.Twilio | null = null;
  private fromNumber: string;

  constructor() {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    this.fromNumber = process.env.TWILIO_PHONE_NUMBER || '';

    if (accountSid && authToken && this.fromNumber) {
      this.client = twilio(accountSid, authToken);
    } else {
      console.warn('Twilio credentials not configured. SMS notifications will be disabled.');
    }
  }

  async sendWeatherAlert(to: string, message: string): Promise<void> {
    if (!this.client) {
      throw new Error('SMS service not configured');
    }

    if (!to.startsWith('+')) {
      throw new Error('Phone number must include country code (e.g., +1234567890)');
    }

    try {
      const result = await this.client.messages.create({
        body: message,
        from: this.fromNumber,
        to: to,
      });

      console.log(`SMS sent successfully. SID: ${result.sid}`);
    } catch (error) {
      console.error('Failed to send SMS:', error);
      throw new Error('Failed to send SMS notification');
    }
  }

  async sendTestSMS(to: string): Promise<void> {
    const message = `🌤️ Weather Alert Test\n\nThis is a test message from your Weather Alert Agent. SMS notifications are working correctly!\n\nTime: ${new Date().toLocaleString()}`;
    await this.sendWeatherAlert(to, message);
  }

  formatWeatherSMS(weatherData: any, location: string, alertType: string): string {
    const temp = weatherData?.currentTemp || 'Unknown';
    const condition = weatherData?.currentCondition || 'Unknown';
    
    let message = `🌤️ Weather Alert - ${alertType}\n\n`;
    message += `Location: ${location}\n`;
    message += `Current: ${temp}, ${condition}\n`;
    
    if (weatherData?.alertData?.alert && weatherData.alertData.alert.length > 0) {
      message += `\nAlerts:\n`;
      weatherData.alertData.alert.forEach((alert: any) => {
        message += `• ${alert.headline}\n`;
      });
    }
    
    message += `\nTime: ${new Date().toLocaleString()}`;
    
    return message;
  }

  isConfigured(): boolean {
    return this.client !== null;
  }
}

export const smsService = new SMSService();