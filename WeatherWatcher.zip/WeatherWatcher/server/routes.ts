import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { weatherService } from "./services/weather";
import { emailService } from "./services/email";
import { smsService } from "./services/sms";
import { schedulerService } from "./services/scheduler";
import { 
  insertUserSchema, 
  insertWeatherSettingsSchema,
  insertActivityLogSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Start weather monitoring scheduler
  schedulerService.startWeatherMonitoring();

  // Get or create user
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user exists
      let user = await storage.getUserByEmail(userData.email);
      if (!user) {
        user = await storage.createUser(userData);
        
        // Create default settings
        await storage.createWeatherSettings({
          userId: user.id,
          frequency: 'immediate',
          conditions: {
            rain: true,
            snow: true,
            storms: true,
            extreme: false
          }
        });
        
        await storage.createActivityLog({
          userId: user.id,
          type: 'user_created',
          message: 'User account created successfully'
        });
      }
      
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Update user location
  app.patch("/api/users/:id/location", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { location, latitude, longitude } = req.body;
      
      const user = await storage.updateUser(userId, {
        location,
        latitude,
        longitude
      });
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      await storage.createActivityLog({
        userId,
        type: 'location_updated',
        message: `Location updated to ${location}`,
        data: { location, latitude, longitude }
      });
      
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Get user dashboard data
  app.get("/api/users/:id/dashboard", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const settings = await storage.getWeatherSettings(userId);
      const weatherData = await storage.getWeatherData(userId);
      const activityLogs = await storage.getActivityLogs(userId, 10);
      const notificationCount = await storage.getNotificationCount(userId);
      
      res.json({
        user,
        settings,
        weatherData,
        activityLogs,
        notificationCount
      });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Get current weather
  app.get("/api/weather/:location", async (req, res) => {
    try {
      const location = req.params.location;
      const weatherData = await weatherService.getCurrentWeather(location);
      res.json(weatherData);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Search locations
  app.get("/api/locations/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ error: "Query parameter required" });
      }
      
      const locations = await weatherService.searchLocation(query);
      res.json(locations);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Get location by coordinates
  app.get("/api/locations/coordinates", async (req, res) => {
    try {
      const lat = parseFloat(req.query.lat as string);
      const lon = parseFloat(req.query.lon as string);
      
      if (isNaN(lat) || isNaN(lon)) {
        return res.status(400).json({ error: "Valid lat and lon parameters required" });
      }
      
      const location = await weatherService.getLocationByCoordinates(lat, lon);
      res.json(location);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Update weather settings
  app.patch("/api/users/:id/settings", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const settingsData = req.body;
      
      const settings = await storage.updateWeatherSettings(userId, settingsData);
      if (!settings) {
        return res.status(404).json({ error: "Settings not found" });
      }
      
      await storage.createActivityLog({
        userId,
        type: 'settings_updated',
        message: 'Weather settings updated successfully',
        data: settingsData
      });
      
      res.json(settings);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Manual weather check
  app.post("/api/users/:id/check-weather", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      const user = await storage.getUser(userId);
      if (!user || !user.location) {
        return res.status(404).json({ error: "User or location not found" });
      }
      
      const weatherData = await weatherService.getCurrentWeather(user.location);
      
      // Update weather data
      await storage.updateWeatherData(userId, {
        userId,
        location: user.location,
        currentTemp: `${weatherData.current.temp_f}°F`,
        currentCondition: weatherData.current.condition.text,
        forecastData: weatherData.forecast,
        alertData: weatherData.alerts
      });
      
      await storage.createActivityLog({
        userId,
        type: 'manual_weather_check',
        message: 'Manual weather check completed',
        data: { location: user.location, temp: weatherData.current.temp_f }
      });
      
      res.json(weatherData);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Send test email
  app.post("/api/users/:id/test-email", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      await emailService.sendTestEmail(user.email);
      
      await storage.createActivityLog({
        userId,
        type: 'test_email_sent',
        message: 'Test email sent successfully',
        data: { email: user.email }
      });
      
      res.json({ message: "Test email sent successfully" });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Send test SMS
  app.post("/api/users/:id/test-sms", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      const user = await storage.getUser(userId);
      const settings = await storage.getWeatherSettings(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      if (!settings?.phoneNumber) {
        return res.status(400).json({ error: "Phone number not configured" });
      }

      if (!smsService.isConfigured()) {
        return res.status(400).json({ error: "SMS service not configured. Please add Twilio credentials." });
      }
      
      await smsService.sendTestSMS(settings.phoneNumber);
      
      await storage.createActivityLog({
        userId,
        type: 'test_sms_sent',
        message: 'Test SMS sent successfully',
        data: { phoneNumber: settings.phoneNumber }
      });
      
      res.json({ message: "Test SMS sent successfully" });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Get activity logs
  app.get("/api/users/:id/logs", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const limit = parseInt(req.query.limit as string) || 50;
      
      const logs = await storage.getActivityLogs(userId, limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}