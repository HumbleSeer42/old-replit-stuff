import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  location: text("location"),
  latitude: text("latitude"),
  longitude: text("longitude"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const weatherSettings = pgTable("weather_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  frequency: text("frequency").notNull().default("immediate"), // immediate, hourly, daily
  conditions: jsonb("conditions").$type<{
    rain: boolean;
    snow: boolean;
    storms: boolean;
    extreme: boolean;
  }>().default({ rain: true, snow: true, storms: true, extreme: false }),
  notificationMethods: jsonb("notification_methods").$type<{
    email: boolean;
    sms: boolean;
  }>().default({ email: true, sms: false }),
  phoneNumber: text("phone_number"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  type: text("type").notNull(), // email_sent, weather_updated, location_updated, etc.
  message: text("message").notNull(),
  data: jsonb("data"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const weatherData = pgTable("weather_data", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  location: text("location").notNull(),
  currentTemp: text("current_temp"),
  currentCondition: text("current_condition"),
  forecastData: jsonb("forecast_data"),
  alertData: jsonb("alert_data"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertWeatherSettingsSchema = createInsertSchema(weatherSettings).omit({
  id: true,
  createdAt: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  createdAt: true,
});

export const insertWeatherDataSchema = createInsertSchema(weatherData).omit({
  id: true,
  updatedAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type WeatherSettings = typeof weatherSettings.$inferSelect;
export type InsertWeatherSettings = z.infer<typeof insertWeatherSettingsSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type WeatherData = typeof weatherData.$inferSelect;
export type InsertWeatherData = z.infer<typeof insertWeatherDataSchema>;
