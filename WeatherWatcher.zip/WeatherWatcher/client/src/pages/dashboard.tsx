import { useQuery, useMutation } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "@/hooks/use-location";
import StatusCards from "@/components/status-cards";
import ForecastCard from "@/components/forecast-card";
import ActivityCard from "@/components/activity-card";
import SettingsCard from "@/components/settings-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ThemeToggle } from "@/components/theme-toggle";
import { CloudSun, Settings, Circle, Shield } from "lucide-react";

export default function Dashboard() {
  const { toast } = useToast();
  const { location, getCurrentLocation, loading: locationLoading } = useLocation();
  const [userId, setUserId] = useState<number | null>(null);

  // Initialize user on component mount
  useEffect(() => {
    const initializeUser = async () => {
      try {
        const email = localStorage.getItem("userEmail") || "user@example.com";
        const response = await apiRequest("POST", "/api/users", { email });
        const userData = await response.json();
        setUserId(userData.id);
        localStorage.setItem("userId", userData.id.toString());
      } catch (error) {
        console.error("Failed to initialize user:", error);
      }
    };

    const savedUserId = localStorage.getItem("userId");
    if (savedUserId) {
      setUserId(parseInt(savedUserId));
    } else {
      initializeUser();
    }
  }, []);

  // Fetch dashboard data
  const { data: dashboardData, isLoading: dashboardLoading } = useQuery({
    queryKey: ["/api/users", userId, "dashboard"],
    enabled: !!userId,
    refetchInterval: 60000, // Refresh every minute
  });

  // Location update mutation
  const locationMutation = useMutation({
    mutationFn: async (locationData: { location: string; latitude: string; longitude: string }) => {
      const response = await apiRequest("PATCH", `/api/users/${userId}/location`, locationData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "dashboard"] });
      toast({
        title: "Success",
        description: "Location updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update location",
        variant: "destructive",
      });
    },
  });

  // Manual weather check mutation
  const weatherCheckMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/users/${userId}/check-weather`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "dashboard"] });
      toast({
        title: "Success",
        description: "Weather data updated",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to check weather",
        variant: "destructive",
      });
    },
  });

  // Test email mutation
  const testEmailMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/users/${userId}/test-email`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "dashboard"] });
      toast({
        title: "Success",
        description: "Test email sent successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send test email",
        variant: "destructive",
      });
    },
  });

  // Test SMS mutation
  const testSMSMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/users/${userId}/test-sms`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "dashboard"] });
      toast({
        title: "Success",
        description: "Test SMS sent successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send test SMS",
        variant: "destructive",
      });
    },
  });

  // Handle location update
  const handleLocationUpdate = async () => {
    if (!location) {
      getCurrentLocation();
      return;
    }

    try {
      const response = await fetch(`/api/locations/coordinates?lat=${location.latitude}&lon=${location.longitude}`);
      const locationData = await response.json();
      
      locationMutation.mutate({
        location: `${locationData.name}, ${locationData.region}`,
        latitude: location.latitude.toString(),
        longitude: location.longitude.toString(),
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get location details",
        variant: "destructive",
      });
    }
  };

  if (!userId || dashboardLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600 dark:text-slate-400">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <header className="bg-white dark:bg-slate-800 shadow-sm border-b border-slate-200 dark:border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <CloudSun className="text-primary text-2xl mr-3" />
              <h1 className="text-xl font-semibold text-slate-900 dark:text-white">Weather Alert Agent</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                <Circle className="w-2 h-2 mr-1 fill-current" />
                Active
              </span>
              <ThemeToggle />
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Status Cards */}
        <StatusCards 
          dashboardData={dashboardData}
          onLocationUpdate={handleLocationUpdate}
          locationLoading={locationLoading || locationMutation.isPending}
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-6">
            <ForecastCard weatherData={dashboardData?.weatherData} />
            <ActivityCard activityLogs={dashboardData?.activityLogs} />
          </div>

          {/* Configuration Sidebar */}
          <div className="space-y-6">
            <SettingsCard 
              user={dashboardData?.user}
              settings={dashboardData?.settings}
              userId={userId}
            />

            {/* API Status Card */}
            <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-slate-900 dark:text-white">API Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600 dark:text-slate-300">Weather API</span>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                      <Circle className="w-2 h-2 mr-1 fill-current" />
                      Connected
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600 dark:text-slate-300">Email Service</span>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                      <Circle className="w-2 h-2 mr-1 fill-current" />
                      Connected
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600 dark:text-slate-300">Location Service</span>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                      <Circle className="w-2 h-2 mr-1 fill-current" />
                      Connected
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Manual Actions Card */}
            <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-slate-900 dark:text-white">Manual Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button
                    onClick={() => weatherCheckMutation.mutate()}
                    disabled={weatherCheckMutation.isPending}
                    className="w-full"
                  >
                    {weatherCheckMutation.isPending ? "Checking..." : "Check Weather Now"}
                  </Button>
                  <Button
                    onClick={() => testEmailMutation.mutate()}
                    disabled={testEmailMutation.isPending}
                    variant="outline"
                    className="w-full"
                  >
                    {testEmailMutation.isPending ? "Sending..." : "Send Test Email"}
                  </Button>
                  {dashboardData?.settings?.notificationMethods?.sms && dashboardData?.settings?.phoneNumber && (
                    <Button
                      onClick={() => testSMSMutation.mutate()}
                      disabled={testSMSMutation.isPending}
                      variant="outline"
                      className="w-full"
                    >
                      {testSMSMutation.isPending ? "Sending..." : "Send Test SMS"}
                    </Button>
                  )}
                  <Button
                    onClick={() => {
                      // Navigate to logs view (can be implemented later)
                      toast({
                        title: "Info",
                        description: "Logs are shown in the Recent Activity section",
                      });
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    View Logs
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
