import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const settingsSchema = z.object({
  email: z.string().email("Please enter a valid email"),
  frequency: z.enum(["immediate", "hourly", "daily"]),
  conditions: z.object({
    rain: z.boolean(),
    snow: z.boolean(),
    storms: z.boolean(),
    extreme: z.boolean(),
  }),
  notificationMethods: z.object({
    email: z.boolean(),
    sms: z.boolean(),
  }),
  phoneNumber: z.string().optional(),
});

type SettingsFormData = z.infer<typeof settingsSchema>;

interface SettingsCardProps {
  user: any;
  settings: any;
  userId: number;
}

export default function SettingsCard({ user, settings, userId }: SettingsCardProps) {
  const { toast } = useToast();

  // Test email mutation
  const testEmailMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/users/${userId}/test-email`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "dashboard"] });
      toast({
        title: "Success",
        description: "Test email sent successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send test email",
        variant: "destructive",
      });
    },
  });

  // Test SMS mutation
  const testSMSMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/users/${userId}/test-sms`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "dashboard"] });
      toast({
        title: "Success",
        description: "Test SMS sent successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send test SMS",
        variant: "destructive",
      });
    },
  });

  const form = useForm<SettingsFormData>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      email: user?.email || "",
      frequency: settings?.frequency || "immediate",
      conditions: {
        rain: settings?.conditions?.rain ?? true,
        snow: settings?.conditions?.snow ?? true,
        storms: settings?.conditions?.storms ?? true,
        extreme: settings?.conditions?.extreme ?? false,
      },
      notificationMethods: {
        email: settings?.notificationMethods?.email ?? true,
        sms: settings?.notificationMethods?.sms ?? false,
      },
      phoneNumber: settings?.phoneNumber || "",
    },
  });

  const settingsMutation = useMutation({
    mutationFn: async (data: SettingsFormData) => {
      const response = await apiRequest("PATCH", `/api/users/${userId}/settings`, {
        frequency: data.frequency,
        conditions: data.conditions,
        notificationMethods: data.notificationMethods,
        phoneNumber: data.phoneNumber,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "dashboard"] });
      toast({
        title: "Success",
        description: "Settings updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update settings",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SettingsFormData) => {
    settingsMutation.mutate(data);
  };

  return (
    <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-slate-900 dark:text-white">Notification Settings</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              Email Address
            </Label>
            <Input
              id="email"
              type="email"
              {...form.register("email")}
              placeholder="your.email@example.com"
              className="w-full"
              readOnly
            />
          </div>

          <div>
            <Label htmlFor="frequency" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              Notification Frequency
            </Label>
            <Select 
              value={form.watch("frequency")} 
              onValueChange={(value) => form.setValue("frequency", value as any)}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="immediate">Immediate</SelectItem>
                <SelectItem value="hourly">Every Hour</SelectItem>
                <SelectItem value="daily">Daily Summary</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              Weather Conditions
            </Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="rain"
                  checked={form.watch("conditions.rain")}
                  onCheckedChange={(checked) => form.setValue("conditions.rain", !!checked)}
                />
                <Label htmlFor="rain" className="text-sm text-slate-700 dark:text-slate-300">
                  Rain
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="snow"
                  checked={form.watch("conditions.snow")}
                  onCheckedChange={(checked) => form.setValue("conditions.snow", !!checked)}
                />
                <Label htmlFor="snow" className="text-sm text-slate-700 dark:text-slate-300">
                  Snow
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="storms"
                  checked={form.watch("conditions.storms")}
                  onCheckedChange={(checked) => form.setValue("conditions.storms", !!checked)}
                />
                <Label htmlFor="storms" className="text-sm text-slate-700 dark:text-slate-300">
                  Thunderstorms
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="extreme"
                  checked={form.watch("conditions.extreme")}
                  onCheckedChange={(checked) => form.setValue("conditions.extreme", !!checked)}
                />
                <Label htmlFor="extreme" className="text-sm text-slate-700 dark:text-slate-300">
                  Extreme Weather
                </Label>
              </div>
            </div>
          </div>

          <div>
            <Label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              Notification Methods
            </Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="email"
                  checked={form.watch("notificationMethods.email")}
                  onCheckedChange={(checked) => form.setValue("notificationMethods.email", !!checked)}
                />
                <Label htmlFor="email" className="text-sm text-slate-700 dark:text-slate-300">
                  Email Notifications
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="sms"
                  checked={form.watch("notificationMethods.sms")}
                  onCheckedChange={(checked) => form.setValue("notificationMethods.sms", !!checked)}
                />
                <Label htmlFor="sms" className="text-sm text-slate-700 dark:text-slate-300">
                  SMS Notifications
                </Label>
              </div>
            </div>
          </div>

          {form.watch("notificationMethods.sms") && (
            <div>
              <Label htmlFor="phoneNumber" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Phone Number (include country code)
              </Label>
              <Input
                id="phoneNumber"
                type="tel"
                {...form.register("phoneNumber")}
                placeholder="+1234567890"
                className="w-full"
              />
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Include country code (e.g., +1 for US, +44 for UK)
              </p>
            </div>
          )}

          <div className="space-y-2">
            <Button
              type="submit"
              disabled={settingsMutation.isPending}
              className="w-full"
            >
              {settingsMutation.isPending ? "Saving..." : "Save Settings"}
            </Button>
            
            <div className="grid grid-cols-2 gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => testEmailMutation.mutate()}
                disabled={testEmailMutation.isPending}
                className="text-xs"
              >
                {testEmailMutation.isPending ? "Sending..." : "Test Email"}
              </Button>
              
              {form.watch("notificationMethods.sms") && form.watch("phoneNumber") && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => testSMSMutation.mutate()}
                  disabled={testSMSMutation.isPending}
                  className="text-xs"
                >
                  {testSMSMutation.isPending ? "Sending..." : "Test SMS"}
                </Button>
              )}
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
