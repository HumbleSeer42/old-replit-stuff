import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sun, CloudRain, Cloud, CloudSnow, Zap } from "lucide-react";

interface ForecastCardProps {
  weatherData: any;
}

export default function ForecastCard({ weatherData }: ForecastCardProps) {
  const forecastData = weatherData?.forecastData?.forecastday || [];

  const getWeatherIcon = (condition: string) => {
    const conditionLower = condition.toLowerCase();
    
    if (conditionLower.includes('rain') || conditionLower.includes('drizzle')) {
      return <CloudRain className="text-blue-500 text-lg w-6" />;
    }
    if (conditionLower.includes('snow') || conditionLower.includes('blizzard')) {
      return <CloudSnow className="text-gray-400 text-lg w-6" />;
    }
    if (conditionLower.includes('thunder') || conditionLower.includes('storm')) {
      return <Zap className="text-yellow-500 text-lg w-6" />;
    }
    if (conditionLower.includes('cloud')) {
      return <Cloud className="text-gray-500 text-lg w-6" />;
    }
    return <Sun className="text-yellow-500 text-lg w-6" />;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    if (date.toDateString() === today.toDateString()) {
      return "Today";
    }
    if (date.toDateString() === tomorrow.toDateString()) {
      return "Tomorrow";
    }
    return date.toLocaleDateString('en-US', { weekday: 'long' });
  };

  if (!forecastData.length) {
    return (
      <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900 dark:text-white">5-Day Forecast</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-600 dark:text-slate-300">No forecast data available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-slate-900 dark:text-white">5-Day Forecast</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {forecastData.map((day: any, index: number) => (
            <div key={index} className="flex items-center justify-between py-4 border-b border-slate-100 dark:border-slate-700 last:border-b-0">
              <div className="flex items-center space-x-4">
                {getWeatherIcon(day.day.condition.text)}
                <div>
                  <p className="font-medium text-slate-900 dark:text-white">{formatDate(day.date)}</p>
                  <p className="text-sm text-slate-600 dark:text-slate-300">{day.day.condition.text}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-slate-900 dark:text-white">{Math.round(day.day.maxtemp_f)}°</p>
                <p className="text-sm text-slate-600 dark:text-slate-300">{Math.round(day.day.mintemp_f)}°</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
