import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, RotateCcw, MapPin, Settings, AlertTriangle } from "lucide-react";

interface ActivityCardProps {
  activityLogs: any[];
}

export default function ActivityCard({ activityLogs }: ActivityCardProps) {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'email_sent':
      case 'test_email_sent':
        return <Mail className="text-primary text-sm" />;
      case 'weather_updated':
      case 'manual_weather_check':
        return <RotateCcw className="text-green-500 text-sm" />;
      case 'location_updated':
        return <MapPin className="text-yellow-500 text-sm" />;
      case 'settings_updated':
        return <Settings className="text-blue-500 text-sm" />;
      case 'error':
        return <AlertTriangle className="text-red-500 text-sm" />;
      default:
        return <RotateCcw className="text-gray-500 text-sm" />;
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes} minutes ago`;
    if (hours < 24) return `${hours} hours ago`;
    return `${days} days ago`;
  };

  if (!activityLogs || activityLogs.length === 0) {
    return (
      <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900 dark:text-white">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-600 dark:text-slate-300">No recent activity</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-slate-900 dark:text-white">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activityLogs.map((log: any, index: number) => (
            <div key={index} className="flex items-start space-x-3 py-4 border-b border-slate-100 dark:border-slate-700 last:border-b-0">
              <div className="flex-shrink-0">
                {getActivityIcon(log.type)}
              </div>
              <div className="flex-1">
                <p className="text-sm text-slate-900 dark:text-white">{log.message}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  {formatTimeAgo(log.createdAt)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
