import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sun, CloudRain, Cloud, CloudSnow, Zap } from "lucide-react";

interface WeatherCardProps {
  weatherData: any;
  location: string;
}

export default function WeatherCard({ weatherData, location }: WeatherCardProps) {
  const getWeatherIcon = (condition: string) => {
    const conditionLower = condition.toLowerCase();
    
    if (conditionLower.includes('rain') || conditionLower.includes('drizzle')) {
      return <CloudRain className="text-blue-500 text-4xl" />;
    }
    if (conditionLower.includes('snow') || conditionLower.includes('blizzard')) {
      return <CloudSnow className="text-gray-400 text-4xl" />;
    }
    if (conditionLower.includes('thunder') || conditionLower.includes('storm')) {
      return <Zap className="text-yellow-500 text-4xl" />;
    }
    if (conditionLower.includes('cloud')) {
      return <Cloud className="text-gray-500 text-4xl" />;
    }
    return <Sun className="text-yellow-500 text-4xl" />;
  };

  if (!weatherData) {
    return (
      <Card className="border border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900">Current Weather</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-600">No weather data available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-slate-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-slate-900">
          Current Weather - {location}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-6">
          {getWeatherIcon(weatherData.currentCondition)}
          <div>
            <p className="text-3xl font-bold text-slate-900">{weatherData.currentTemp}</p>
            <p className="text-lg text-slate-600">{weatherData.currentCondition}</p>
          </div>
        </div>
        
        {weatherData.alertData?.alert && weatherData.alertData.alert.length > 0 && (
          <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <h4 className="font-semibold text-red-800 mb-2">Weather Alerts</h4>
            {weatherData.alertData.alert.map((alert: any, index: number) => (
              <div key={index} className="mb-2">
                <p className="font-medium text-red-700">{alert.headline}</p>
                <p className="text-sm text-red-600">{alert.desc}</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
