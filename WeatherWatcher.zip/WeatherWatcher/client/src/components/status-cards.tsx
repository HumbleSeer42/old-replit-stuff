import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Sun, Shield, Mail, RotateCcw } from "lucide-react";

interface StatusCardsProps {
  dashboardData: any;
  onLocationUpdate: () => void;
  locationLoading: boolean;
}

export default function StatusCards({ dashboardData, onLocationUpdate, locationLoading }: StatusCardsProps) {
  const user = dashboardData?.user;
  const weatherData = dashboardData?.weatherData;
  const notificationCount = dashboardData?.notificationCount || 0;

  const getAlertStatus = () => {
    if (weatherData?.alertData?.alert && weatherData.alertData.alert.length > 0) {
      return {
        status: "Active Alerts",
        color: "text-red-600",
        icon: "text-red-500"
      };
    }
    return {
      status: "No Alerts",
      color: "text-green-600",
      icon: "text-green-500"
    };
  };

  const alertStatus = getAlertStatus();

  const getLastChecked = () => {
    if (weatherData?.updatedAt) {
      const diff = Date.now() - new Date(weatherData.updatedAt).getTime();
      const minutes = Math.floor(diff / (1000 * 60));
      if (minutes < 1) return "Just now";
      if (minutes < 60) return `${minutes} minutes ago`;
      const hours = Math.floor(minutes / 60);
      if (hours < 24) return `${hours} hours ago`;
      return `${Math.floor(hours / 24)} days ago`;
    }
    return "Never";
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {/* Current Location Card */}
      <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Current Location</p>
              <p className="text-lg font-semibold text-slate-900 dark:text-white">
                {user?.location || "Location not set"}
              </p>
            </div>
            <MapPin className="text-primary text-xl" />
          </div>
          <div className="mt-4">
            <Button
              onClick={onLocationUpdate}
              disabled={locationLoading}
              variant="ghost"
              size="sm"
              className="text-sm text-primary hover:text-primary/80 font-medium p-0 h-auto"
            >
              {locationLoading ? (
                <RotateCcw className="w-3 h-3 mr-1 animate-spin" />
              ) : (
                <RotateCcw className="w-3 h-3 mr-1" />
              )}
              Update Location
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Current Weather Card */}
      <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Current Weather</p>
              <p className="text-lg font-semibold text-slate-900 dark:text-white">
                {weatherData?.currentTemp || "Not available"}
              </p>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                {weatherData?.currentCondition || "Unknown"}
              </p>
            </div>
            <Sun className="text-yellow-500 text-xl" />
          </div>
        </CardContent>
      </Card>

      {/* Alert Status Card */}
      <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Alert Status</p>
              <p className={`text-lg font-semibold ${alertStatus.color}`}>
                {alertStatus.status}
              </p>
            </div>
            <Shield className={`${alertStatus.icon} text-xl`} />
          </div>
          <div className="mt-4">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Last checked: {getLastChecked()}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Notifications Sent Card */}
      <Card className="border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Notifications Sent</p>
              <p className="text-lg font-semibold text-slate-900 dark:text-white">{notificationCount}</p>
              <p className="text-sm text-slate-600 dark:text-slate-300">This month</p>
            </div>
            <Mail className="text-primary text-xl" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
